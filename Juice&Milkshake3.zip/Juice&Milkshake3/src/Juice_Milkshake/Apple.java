package Juice_Milkshake;

public class Apple {

}

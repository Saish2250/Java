package Juice_Milkshake;

public abstract class Orange extends Juice {

}

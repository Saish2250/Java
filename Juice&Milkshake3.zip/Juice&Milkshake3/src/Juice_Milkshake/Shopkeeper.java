package Juice_Milkshake;

import java.util.ArrayList;
import java.util.List;

public class Shopkeeper {
	
	void service1() {
		System.out.println("Choose a drink");
	}
	void service2() {
		System.out.println("Your order will be ready soon");
	}
	void service3() {
		System.out.println("Your order is ready");
	}

	void service4() {
		Shop d=new Shop();
		List<String> adrink = new ArrayList<>();
		adrink.add("Mango Shake");
		adrink.add("Pineapple Juice");
		adrink.add("chikoo shake");
		System.out.println(adrink+" are  ready");
	}
	

}

package Juice_Milkshake;

public class Banana extends Milkshake{

}

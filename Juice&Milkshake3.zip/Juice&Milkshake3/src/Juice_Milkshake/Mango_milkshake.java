package Juice_Milkshake;

public class Mango_milkshake extends Milkshake{

}

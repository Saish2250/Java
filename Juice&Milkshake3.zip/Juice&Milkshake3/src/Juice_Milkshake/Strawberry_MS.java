package Juice_Milkshake;

public class Strawberry_MS extends Milkshake{
	

}

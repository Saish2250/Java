package Juice_Milkshake;

public class Chicoo_MS extends Milkshake{
	
	

}

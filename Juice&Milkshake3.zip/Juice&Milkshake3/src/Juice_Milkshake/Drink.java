package Juice_Milkshake;

public abstract class Drink {
	
	void available() {
		System.out.println("Juice and Milkshake are Available");
	}
	
	}



package Juice_Milkshake;

public abstract class Lime {

}

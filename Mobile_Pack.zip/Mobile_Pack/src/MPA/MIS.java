package MPA;
import java.util.HashMap;
import java.util.List;
//import java.util.Map;
import java.util.Map;


public class MIS extends Mobile {
	Mobile bname;
	
	private List<Mobile> brandname1;
	
	
	public List<Mobile> getBrandname1() {
		return brandname1;
	}

	public void setBrandname1(List<Mobile> brandname1) {
		this.brandname1 = brandname1;
	}
	public void search() {
		//Map<String,String> ma = new HashMap<String,String>();
		
	}
	
	public void showfeatures() {
		
		//System.out.println("Brandname: "+brandname);
		
		
	}
	
	public void differentmobiles() {
		
	}
	
	
	public void listbrandname(List<String> bname) {
		
	}
	
	public void listbyprice() {
		
	}
	
	
	
	void byversion() {
		
	}
	
	void byram()
	{
		
	}
	
	void byprocessor() {
		
	}
	
	public List<Mobile> modelname{
		Map<String,Mobile> mm = new HashMap<String,Mobile>();
		mm.put(mm, m4);
	}

	
	
	
}
